package com.example.intro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
