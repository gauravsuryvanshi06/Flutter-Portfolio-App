import 'package:flutter/material.dart';

///home/gd081sa/snap/flutter/common/flutter/.pub-cache/hosted/pub.dartlang.org/url_launcher_web-2.0.7/lib/url_launcher_web.dart
///home/gd081sa/snap/flutter/common/flutter/.pub-cache/hosted/pub.dartlang.org/url_launcher_web-2.0.7/lib/url_launcher_web.dart
// import 'package:url_launcher/link.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white38,
        body: Container(
          child: Column(
            children: const [
              CircleAvatar(
                radius: 120.0,
                backgroundImage: AssetImage('images/g.png'),
              ),
              Text(
                "\n    Gaurav \n Suryavanshi",
                style: TextStyle(
                  fontFamily: 'Great Vibes',
                  fontSize: 50.0,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3.0,
                  height: 0.8,
                  color: Colors.black,
                ),
              ),
              Text(
                "              ~Software Developer",
                style: TextStyle(
                  fontFamily: 'Great Vibes',
                  fontSize: 30.0,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2.0,
                  height: 2.0,
                  color: Colors.black,
                ),
              ),
              Text("\n\n"),
              Card(
                color: Colors.greenAccent,
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                  leading: Icon(Icons.phone, color: Colors.blue),
                  title: Text("   WhatsApp...+9190***29332",
                      style: TextStyle(
                        fontFamily: 'Great Vibes',
                        fontSize: 30.0,
                        fontWeight: FontWeight.bold,
                        // letterSpacing: 2.0,
                        // height: 3.0,
                      )),
                ),
              ),
              Card(
                color: Colors.greenAccent,
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                    leading: Icon(Icons.email, color: Colors.lightBlueAccent),
                    title: Text("   Gauravsuryavanshi7484@gmail.com",
                        style: TextStyle(
                          fontFamily: 'Great Vibes',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          // letterSpacing: 2.0,
                          // height: 3.0,
                        ))),
              ),
              Card(
                color: Colors.greenAccent,
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                    leading: Icon(Icons.email, color: Colors.lightBlueAccent),
                    title: Text("  Linkdin Profile",
                        style: TextStyle(
                          fontFamily: 'Great Vibes',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          // letterSpacing: 2.0,
                          // height: 3.0,
                        ))),
              ),
              Card(
                color: Colors.greenAccent,
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                    leading: Icon(Icons.email, color: Colors.lightBlueAccent),
                    title: Text("  Github Profile",
                        style: TextStyle(
                          fontFamily: 'Great Vibes',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          // letterSpacing: 2.0,
                          // height: 3.0,
                        ))),
              ),
              Card(
                color: Colors.greenAccent,
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                    leading: Icon(Icons.email, color: Colors.lightBlueAccent),
                    title: Text("  Instagram",
                        style: TextStyle(
                          fontFamily: 'Great Vibes',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          // letterSpacing: 2.0,
                          // height: 3.0,
                        ))),
              ),
              Card(
                color: Colors.greenAccent,
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                    leading: Icon(Icons.email, color: Colors.lightBlueAccent),
                    title: Text("  Flutter-Blogs",
                        style: TextStyle(
                          fontFamily: 'Great Vibes',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          // letterSpacing: 2.0,
                          // height: 3.0,
                        ))),
              ),
              Card(
                color: Colors.greenAccent,
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                    leading: Icon(Icons.email, color: Colors.lightBlueAccent),
                    title: Text("  Medium",
                        style: TextStyle(
                          fontFamily: 'Great Vibes',
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          // letterSpacing: 2.0,
                          // height: 3.0,
                        ))),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
